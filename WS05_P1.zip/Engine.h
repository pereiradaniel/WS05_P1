// I have done all the coding by myselfand only copied the code that my professor
// provided to complete my workshopsand assignments.
//
// Name:			Daniel Pereira
// Seneca email:	dppereira@myseneca.ca
// Student ID:		037747078
// Date:  Thursday, 25/June/2020

#pragma once
#ifndef SDDS_ENGINE_H
#define SDDS_ENGINE_H

namespace sdds
{
	const int	TYPE_MAX_SIZE = 30;					// Max length of the type attribute in Engine class.
	
	class Engine
	{
		private:
			double	m_size;							// The size of an engine, as a floating point number in double precision.
			char	m_type[TYPE_MAX_SIZE + 1]; 		// The engine model type, as an array of chars of size TYPE_MAX_SIZE.

		public:
			Engine();								// Default constructor.
			// ~Engine() = default;					// Default destructor.
			Engine(const char* type, double size);	// Custom constructor that rx's as params: engine type, size.
			double get() const;						// Query that returns the size of the engine.
			void display() const;					// Query that prints to the screen the content of an object in the format [SIZE] - liters - [TYPE] <ENDL>
			void initializeEngine();
	};
}

#endif
